---
title: PettingZoo API
firstpage:
---

## PettingZoo API

```{include} ../../README.md
:start-after: <!-- start pettingzoo -->
:end-before: <!-- end pettingzoo -->
```
