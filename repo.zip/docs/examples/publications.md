---
title: Publications
firstpage:
---

## List of Publications

```{include} ../../README.md
:start-after: <!-- start list of publications -->
:end-before: <!-- end list of publications -->
```
