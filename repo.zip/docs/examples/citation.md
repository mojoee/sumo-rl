---
title: Citation
firstpage:
---

## Citation

```{include} ../../README.md
:start-after: <!-- start citation -->
:end-before: <!-- end citation -->
```
