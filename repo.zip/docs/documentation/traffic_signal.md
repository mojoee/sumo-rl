# Traffic Signal

```{eval-rst}
.. autoclass:: sumo_rl.environment.traffic_signal.TrafficSignal
    :members:
```
