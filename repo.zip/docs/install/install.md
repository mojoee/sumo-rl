# Install

```{include} ../../README.md
:start-after: <!-- start install -->
:end-before: <!-- end install -->
```
