---
title: Observation
firstpage:
---

## Observation

```{include} ../../README.md
:start-after: <!-- start observation -->
:end-before: <!-- end observation -->
```
