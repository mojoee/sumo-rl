"""Module for exploration strategies."""

from sumo_rl.exploration.epsilon_greedy import EpsilonGreedy
